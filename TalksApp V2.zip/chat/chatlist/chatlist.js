export function read() {
	const right = document.querySelectorAll(".chat .content .subcontent .contact .right")
	
	right.forEach((i,l) => {
		if (i.querySelector(".count").innerHTML == " 0 ") {
			i.classList.add("read")
		} else {
			i.classList.remove("read")
		}
	})
}

export function unread() {
	const contact = document.querySelectorAll(".chat .content .subcontent .contact")
	const input = document.querySelector(".chat .header .search input")
	
	document.querySelector(".chat .content .subnav .unread").addEventListener("click",() => {
		contact.forEach((i,l) => {
			if (i.querySelector(".right .count").innerHTML == " 0 ") {
				i.style.display = "none"
			}
		})
	})
	
	document.querySelector(".chat .content .subnav .all").addEventListener("click",() => {
		contact.forEach((i,l) => {
			i.style.display = "flex"
		})
	})
}

export function find() {
	const contact = document.querySelectorAll(".chat .content .subcontent .contact")
	const input = document.querySelector(".chat .header .search input")
	
	const key = input.value.toLowerCase().replace(" ","")
	
	contact.forEach((i,l) => {
		if (i.querySelector(".left .name").innerHTML.toLowerCase().replace(" ","").includes(key)) {
			if (document.querySelector(".chat .content .subnav .unread").classList.contains("active")) {
				if (i.querySelector(".right .count").innerHTML == " 0 ") {
					i.style.display = "none"
				} else {
					i.style.display = "flex"
				}
			} else {
				i.style.display = "flex"
			}
		} else {
			i.style.display = "none"
		}
	})
	
	requestAnimationFrame(find)
}